package com.po;

public class HelloWorldPo {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    //静态工厂方法
    public static HelloWorldPo getInstances(){
        return new HelloWorldPo();
    }
	
	@Override
	public String toString() {
		return "HelloWorldPo [name=" + name + "]";
	}
}
