package com.po;

public class HelloWorldInstanceFactory {

	public HelloWorldPo getInstance() {
		HelloWorldPo helloWorldPo = new HelloWorldPo();
		return helloWorldPo;
	}
}
