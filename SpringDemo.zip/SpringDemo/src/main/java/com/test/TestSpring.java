package com.test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.po.HelloWorldPo;

public class TestSpring {
	
	@Test
	public void testHello(){
		//通过new创建实例对象
		HelloWorldPo helloWorldPo=new HelloWorldPo();
		helloWorldPo.setName("new");
		System.out.println(helloWorldPo.toString());
	}
	//通过反射创建实例对象
	@Test
	public void testInvoke() throws Exception{
		Class class1 = Class.forName("com.po.HelloWorldPo");
		//获取属性对象
		Field field = class1.getDeclaredField("name");
		//获取方法对象
		Method method = class1.getMethod("setName", String.class);
		//通过反射创建实例对象
		HelloWorldPo helloWorldPo=(HelloWorldPo) class1.newInstance();
		//通过反射调用方法
		method.invoke(helloWorldPo, "反射");
		
		System.out.println(helloWorldPo.toString());
	}
	
	//构造方法
	@Test
	public void testConstructor(){
		//spring是个容器，负责管理对象的生命周期
		
//		需要实例化IOC容器，容器产生哪些实例，是根据配置文件来产生的
//		容器实例化之后，才可以从IOC容器获取Bean的实例并使用
//		如何实例化IOC容器
//		1.BeanFacotry .IOC容器的基本实现，面向的是Spring本身
//		2.ApplicationContxt.是BeanFactory的子接口，ApplicationContext是面向
//		spring框架的使用者，所有的应用基本上都是满足
//		ApplicationContext实现类：
//			1.ClassPathXmlApplicationContext 从类路径下加载配置文件（src）
//		    2.FileSystemXmlApplicationContext 从系统文件中加载配置文件（F://cxx/xxx/xxx.xml）
//		ConfigurableApplicationContext 扩展ApllicationContext.
//		功能：启动，刷新，关闭上下文的功能
//      ApplicationContext 特点：在初始化上下文时就已经实例化好所有的的实例（单例）
//	           针对web项目，上下文使用 WebApplicationContext	
		AbstractApplicationContext applicationContext 
		= new ClassPathXmlApplicationContext("applicationContext.xml");
		//在容器中获取 class类型为HelloWorldPo 的bean 
		//容器中只有一个class类型相同的bean 才可以使用 getBean(Class);
		HelloWorldPo helloWorldPo=(HelloWorldPo) applicationContext.getBean("helloWorldByDefaultConstructor");
		System.out.println(helloWorldPo.toString());
	}
	
	//静态工厂
	@Test
	public void testStaticFactory(){
		//spring是个容器，负责管理对象的生命周期
		AbstractApplicationContext applicationContext 
		= new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorldPo helloWorldPo=(HelloWorldPo) applicationContext.getBean("helloWorldByStaticFactory");
		System.out.println(helloWorldPo.toString());
	}
	
	//实例工厂
	@Test
	public void testInstanceFactory(){
		//spring是个容器，负责管理对象的生命周期
		AbstractApplicationContext applicationContext 
		= new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorldPo helloWorldPo=(HelloWorldPo) applicationContext.getBean("helloWorldByInstanceFactory");
		System.out.println(helloWorldPo.toString());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
